import { Button } from "@/components/ui/button";
import { getLoginUrl, getDiscordLoginUrl } from "@/const";
import { Link, useLocation } from "wouter";
import { Code2, Menu, X, ChevronDown, LogOut, User, ShoppingCart, Mail } from "lucide-react";
import ThemeSwitcher from "./ThemeSwitcher";
import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { useCart } from "@/contexts/CartContext";
import { useAuth } from "@/_core/hooks/useAuth";

export default function Navbar() {
  const { user, isAuthenticated } = useAuth();
  const { items } = useCart();
  const [isOpen, setIsOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [, setLocation] = useLocation();
  
  const logoutMutation = trpc.auth.logout.useMutation({
    onSuccess: () => {
      toast.success("تم تسجيل الخروج بنجاح");
      setLocation("/");
      setIsUserMenuOpen(false);
    },
  });

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <nav className="sticky top-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
      <div className="container">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/">
            <div className="flex items-center gap-2 cursor-pointer hover:opacity-80 transition-opacity">
              <img 
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663379901621/6RCbR3DpAk72wXbykQAfiA/ideogram-v3.0_Luxury_3D_metallic_logo_for_Scripts_Store_modern_tech_corporate_style_silver_chr-0_d0ca3e45.jpg" 
                alt="Scripts Store Logo"
                className="w-10 h-10 object-contain"
              />
              <span className="text-xl font-bold text-foreground hidden sm:inline">Scripts Store</span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            {/* Main Links */}
            <Link href="/shop" className="text-sm font-medium hover:text-accent transition-colors">
              المتجر
            </Link>

            <Link href="/whats-new" className="text-sm font-medium hover:text-accent transition-colors">
              ما الجديد
            </Link>

            {isAuthenticated && (
              <>
                <Link href="/dashboard" className="text-sm font-medium hover:text-accent transition-colors">
                  لوحة التحكم
                </Link>
                <Link href="/upload" className="text-sm font-medium hover:text-accent transition-colors">
                  رفع سكربت
                </Link>
                <Link href="/ai-writer" className="text-sm font-medium hover:text-accent transition-colors">
                  AI كاتب
                </Link>
                <Link href="/ticket" className="text-sm font-medium hover:text-accent transition-colors">
                  تذكرة دعم
                </Link>

                {user?.role === "admin" && (
                  <Link href="/admin/scripts" className="text-sm font-medium hover:text-accent transition-colors">
                    إدارة السكربتات
                  </Link>
                )}
              </>
            )}

            {/* Support Link */}
            <a
              href="https://discord.com/channels/1472587365364006934/1472594466496975009"
              target="_blank"
              rel="noopener noreferrer"
              className="text-sm font-medium hover:text-accent transition-colors"
            >
              الدعم الفني
            </a>

            {/* Cart Link */}
            <Link href="/cart" className="relative text-sm font-medium hover:text-accent transition-colors">
              <ShoppingCart className="w-5 h-5" />
              {items.length > 0 && (
                <span className="absolute -top-2 -right-2 bg-accent text-background text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                  {items.length}
                </span>
              )}
            </Link>
          </div>

          {/* Right Section */}
          <div className="flex items-center gap-2">
            <ThemeSwitcher />
            {isAuthenticated ? (
              <div className="relative">
                <button
                  onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                  className="flex items-center gap-2 px-4 py-2 rounded-lg hover:bg-muted transition-colors"
                >
                  <User className="w-4 h-4" />
                  <span className="text-sm font-medium hidden sm:inline">{user?.name}</span>
                  <ChevronDown className="w-4 h-4" />
                </button>

                {/* User Dropdown Menu */}
                {isUserMenuOpen && (
                  <div className="absolute right-0 mt-2 w-48 bg-background border border-border rounded-lg shadow-lg overflow-hidden">
                    <Link href="/dashboard">
                      <div className="px-4 py-2 hover:bg-muted transition-colors cursor-pointer flex items-center gap-2">
                        <User className="w-4 h-4" />
                        <span className="text-sm">الملف الشخصي</span>
                      </div>
                    </Link>

                    {user?.role === "admin" && (
                      <Link href="/admin/scripts">
                        <div className="px-4 py-2 hover:bg-muted transition-colors cursor-pointer border-t border-border">
                          <span className="text-sm">إدارة السكربتات</span>
                        </div>
                      </Link>
                    )}

                    <button
                      onClick={handleLogout}
                      className="w-full px-4 py-2 hover:bg-muted transition-colors text-left flex items-center gap-2 border-t border-border text-red-600 hover:text-red-700"
                    >
                      <LogOut className="w-4 h-4" />
                      <span className="text-sm">تسجيل الخروج</span>
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Link href="/auth">
                  <Button size="sm" className="bg-accent hover:bg-accent/90 flex items-center gap-2">
                    <Mail className="w-4 h-4" />
                    <span className="hidden sm:inline">Gmail</span>
                  </Button>
                </Link>
              </div>
            )}

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="md:hidden p-2 hover:bg-muted rounded-lg transition-colors"
            >
              {isOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="md:hidden border-t border-border bg-background/95 backdrop-blur-sm">
            <div className="container py-4 space-y-3">
              <Link href="/shop">
                <div className="px-4 py-2 hover:bg-muted rounded-lg transition-colors cursor-pointer">
                  <span className="text-sm font-medium">المتجر</span>
                </div>
              </Link>

              <Link href="/whats-new">
                <div className="px-4 py-2 hover:bg-muted rounded-lg transition-colors cursor-pointer">
                  <span className="text-sm font-medium">ما الجديد</span>
                </div>
              </Link>

              {isAuthenticated && (
                <>
                  <Link href="/dashboard">
                    <div className="px-4 py-2 hover:bg-muted rounded-lg transition-colors cursor-pointer">
                      <span className="text-sm font-medium">لوحة التحكم</span>
                    </div>
                  </Link>

                  {user?.role === "admin" && (
                    <Link href="/admin/scripts">
                      <div className="px-4 py-2 hover:bg-muted rounded-lg transition-colors cursor-pointer">
                        <span className="text-sm font-medium">إدارة السكربتات</span>
                      </div>
                    </Link>
                  )}
                </>
              )}

              <a
                href="https://discord.com/channels/1472587365364006934/1472594466496975009"
                target="_blank"
                rel="noopener noreferrer"
                className="block px-4 py-2 hover:bg-muted rounded-lg transition-colors cursor-pointer"
              >
                <span className="text-sm font-medium">الدعم الفني</span>
              </a>

              {!isAuthenticated && (
                <Link href="/auth" className="block">
                  <Button size="sm" className="w-full bg-accent hover:bg-accent/90 flex items-center justify-center gap-2">
                    <Mail className="w-4 h-4" />
                    <span>Gmail</span>
                  </Button>
                </Link>
              )}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
