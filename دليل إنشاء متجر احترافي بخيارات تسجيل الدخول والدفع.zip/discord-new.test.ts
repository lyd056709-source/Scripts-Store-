import { describe, it, expect } from "vitest";
import { ENV } from "./_core/env";

describe("Discord OAuth Configuration - New Keys", () => {
  it("should have Discord Client ID configured", () => {
    expect(ENV.discordClientId).toBeDefined();
    expect(ENV.discordClientId).toBe("1476709217606959136");
    expect(ENV.discordClientId.length).toBeGreaterThan(0);
  });

  it("should have Discord Client Secret configured", () => {
    expect(ENV.discordClientSecret).toBeDefined();
    expect(ENV.discordClientSecret.length).toBeGreaterThan(0);
  });

  it("should have valid Discord Client ID format", () => {
    expect(ENV.discordClientId).toMatch(/^\d+$/);
  });

  it("should have valid Discord Client Secret format", () => {
    expect(ENV.discordClientSecret).toMatch(/^[a-zA-Z0-9_-]+$/);
  });
});
