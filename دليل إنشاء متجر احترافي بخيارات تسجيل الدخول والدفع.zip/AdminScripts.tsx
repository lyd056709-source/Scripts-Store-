import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useLocation } from "wouter";
import { Upload, Plus, Trash2, Edit2, Loader2 } from "lucide-react";
import { toast } from "sonner";

export default function AdminScripts() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [showForm, setShowForm] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    category: "",
    price: "",
    image: null as File | null,
    file: null as File | null,
  });

  if (user?.role !== "admin") {
    setLocation("/");
    return null;
  }

  const { data: scripts = [], isLoading: scriptsLoading, refetch } = trpc.scripts.list.useQuery();

  const addScriptMutation = trpc.admin.addScript.useMutation({
    onSuccess: () => {
      toast.success("تم إضافة السكربت بنجاح");
      setFormData({
        title: "",
        description: "",
        category: "",
        price: "",
        image: null,
        file: null,
      });
      setShowForm(false);
      setIsLoading(false);
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || "حدث خطأ في إضافة السكربت");
      setIsLoading(false);
    },
  });

  const deleteScriptMutation = trpc.admin.deleteScript.useMutation({
    onSuccess: () => {
      toast.success("تم حذف السكربت بنجاح");
      refetch();
    },
    onError: () => {
      toast.error("حدث خطأ في حذف السكربت");
    },
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, files } = e.target;
    if (files?.[0]) {
      setFormData(prev => ({
        ...prev,
        [name]: files[0],
      }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.title || !formData.category || !formData.price || !formData.file) {
      toast.error("يرجى ملء جميع الحقول المطلوبة");
      return;
    }

    setIsLoading(true);

    try {
      const fileKey = `scripts/${Date.now()}-${formData.file.name}`;
      
      addScriptMutation.mutate({
        title: formData.title,
        description: formData.description,
        category: formData.category,
        price: parseFloat(formData.price),
        version: "1.0.0",
        fileKey: fileKey,
        fileSize: formData.file.size,
        imageUrl: formData.image ? URL.createObjectURL(formData.image) : undefined,
      });
    } catch (error) {
      toast.error("حدث خطأ في معالجة الملف");
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted">
      {/* Header */}
      <div className="bg-background/80 backdrop-blur-md border-b border-border">
        <div className="container py-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold mb-2">إدارة السكربتات</h1>
              <p className="text-muted-foreground">أضف وعدّل السكربتات المتاحة للبيع</p>
            </div>
            <Button
              onClick={() => setShowForm(!showForm)}
              className="bg-accent hover:bg-accent/90 gap-2"
            >
              <Plus className="w-4 h-4" />
              إضافة سكربت جديد
            </Button>
          </div>
        </div>
      </div>

      {/* Add Script Form */}
      {showForm && (
        <div className="container py-8">
          <Card className="card-elegant">
            <h2 className="text-2xl font-bold mb-6">إضافة سكربت جديد</h2>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium mb-2">اسم السكربت *</label>
                  <Input
                    type="text"
                    name="title"
                    value={formData.title}
                    onChange={handleInputChange}
                    placeholder="مثال: Auto Clicker Bot"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">الفئة *</label>
                  <select
                    name="category"
                    value={formData.category}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 rounded-lg border border-border bg-background text-foreground"
                    required
                  >
                    <option value="">اختر الفئة</option>
                    <option value="Automation">أتمتة</option>
                    <option value="Tools">أدوات</option>
                    <option value="Utilities">برامج مساعدة</option>
                    <option value="Games">ألعاب</option>
                    <option value="Other">أخرى</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">السعر (USD) *</label>
                  <Input
                    type="number"
                    name="price"
                    value={formData.price}
                    onChange={handleInputChange}
                    placeholder="29.99"
                    step="0.01"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">الإصدار</label>
                  <Input
                    type="text"
                    name="version"
                    placeholder="1.0.0"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">الوصف</label>
                <textarea
                  name="description"
                  value={formData.description}
                  onChange={handleInputChange}
                  placeholder="وصف تفصيلي للسكربت..."
                  rows={4}
                  className="w-full px-4 py-2 rounded-lg border border-border bg-background text-foreground"
                />
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium mb-2">صورة المنتج</label>
                  <div className="border-2 border-dashed border-border rounded-lg p-4 text-center cursor-pointer hover:border-accent transition-colors">
                    <input
                      type="file"
                      name="image"
                      accept="image/*"
                      onChange={handleFileChange}
                      className="hidden"
                      id="image-input"
                    />
                    <label htmlFor="image-input" className="cursor-pointer">
                      <Upload className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
                      <p className="text-sm text-muted-foreground">
                        {formData.image?.name || "اختر صورة"}
                      </p>
                    </label>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">ملف السكربت *</label>
                  <div className="border-2 border-dashed border-border rounded-lg p-4 text-center cursor-pointer hover:border-accent transition-colors">
                    <input
                      type="file"
                      name="file"
                      onChange={handleFileChange}
                      className="hidden"
                      id="file-input"
                      required
                    />
                    <label htmlFor="file-input" className="cursor-pointer">
                      <Upload className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
                      <p className="text-sm text-muted-foreground">
                        {formData.file?.name || "اختر الملف"}
                      </p>
                    </label>
                  </div>
                </div>
              </div>

              <div className="flex gap-4 justify-end">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setShowForm(false)}
                  disabled={isLoading}
                >
                  إلغاء
                </Button>
                <Button 
                  type="submit" 
                  className="bg-accent hover:bg-accent/90"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      جاري الإضافة...
                    </>
                  ) : (
                    "إضافة السكربت"
                  )}
                </Button>
              </div>
            </form>
          </Card>
        </div>
      )}

      {/* Scripts List */}
      <div className="container py-12">
        <div className="space-y-4">
          {scriptsLoading ? (
            <div className="grid gap-4">
              {[...Array(3)].map((_, i) => (
                <Card key={i} className="h-24 animate-pulse bg-muted" />
              ))}
            </div>
          ) : scripts.length === 0 ? (
            <Card className="card-elegant text-center py-12">
              <p className="text-lg text-muted-foreground mb-4">لا توجد سكربتات بعد</p>
              <Button onClick={() => setShowForm(true)} className="bg-accent hover:bg-accent/90">
                أضف أول سكربت
              </Button>
            </Card>
          ) : (
            scripts.map((script) => (
              <Card key={script.id} className="card-elegant">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <h3 className="font-bold text-lg mb-1">{script.title}</h3>
                    <p className="text-sm text-muted-foreground mb-2">{script.description}</p>
                    <div className="flex gap-4 text-sm">
                      <span className="bg-accent/10 text-accent px-2 py-1 rounded">
                        {script.category}
                      </span>
                      <span className="text-muted-foreground">
                        السعر: ${parseFloat(script.price).toFixed(2)}
                      </span>
                      <span className="text-muted-foreground">
                        التحميلات: {script.downloads}
                      </span>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline">
                      <Edit2 className="w-4 h-4" />
                    </Button>
                    <Button 
                      size="sm" 
                      variant="outline" 
                      className="text-red-600 hover:bg-red-50"
                      onClick={() => deleteScriptMutation.mutate({ scriptId: script.id })}
                      disabled={deleteScriptMutation.isPending}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
