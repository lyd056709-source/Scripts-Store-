import { Client, GatewayIntentBits, ChannelType, EmbedBuilder } from "discord.js";

let discordClient: Client | null = null;
let isConnected = false;

export async function initializeDiscordBot() {
  const token = process.env.DISCORD_BOT_TOKEN;
  const roomId = process.env.DISCORD_ROOM_ID;

  if (!token || !roomId) {
    console.log("[Discord Bot] Token or Room ID not configured");
    return;
  }

  try {
    discordClient = new Client({
      intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.DirectMessages,
      ],
    });

    discordClient.on("ready", () => {
      console.log(`[Discord Bot] ✅ Bot logged in as ${discordClient?.user?.tag}`);
      isConnected = true;
    });

    discordClient.on("error", (error) => {
      console.error("[Discord Bot] Error:", error);
      isConnected = false;
    });

    await discordClient.login(token);
  } catch (error) {
    console.error("[Discord Bot] Failed to initialize:", error);
    isConnected = false;
  }
}

export async function sendDiscordMessage(
  message: string,
  options?: {
    title?: string;
    color?: string;
    fields?: Array<{ name: string; value: string; inline?: boolean }>;
  }
) {
  if (!discordClient || !isConnected) {
    console.log("[Discord Bot] Bot not connected");
    return false;
  }

  const roomId = process.env.DISCORD_ROOM_ID;
  if (!roomId) {
    console.log("[Discord Bot] Room ID not configured");
    return false;
  }

  try {
    const channel = await discordClient.channels.fetch(roomId);

    if (!channel || channel.type !== ChannelType.GuildText) {
      console.error("[Discord Bot] Invalid channel");
      return false;
    }

    if (options?.title) {
      // Send as embed
      const embed = new EmbedBuilder()
        .setTitle(options.title)
        .setDescription(message)
        .setColor(options.color || "#0099ff")
        .setTimestamp();

      if (options.fields) {
        embed.addFields(options.fields);
      }

      await channel.send({ embeds: [embed] });
    } else {
      // Send as plain message
      await channel.send(message);
    }

    console.log("[Discord Bot] ✅ Message sent successfully");
    return true;
  } catch (error) {
    console.error("[Discord Bot] Failed to send message:", error);
    return false;
  }
}

export function isDiscordBotConnected() {
  return isConnected;
}

export function getDiscordClient() {
  return discordClient;
}
