import { useCart } from "@/contexts/CartContext";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Trash2, ShoppingCart, Minus, Plus } from "lucide-react";
import { Link } from "wouter";

export default function Cart() {
  const { items, removeFromCart, updateQuantity, clearCart, total } = useCart();

  if (items.length === 0) {
    return (
      <div className="min-h-screen bg-background pt-20">
        <div className="container max-w-4xl mx-auto px-4">
          <div className="text-center py-12">
            <ShoppingCart className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
            <h1 className="text-3xl font-bold mb-2">سلة المشتريات فارغة</h1>
            <p className="text-muted-foreground mb-6">
              لم تضف أي منتجات إلى السلة بعد
            </p>
            <Link href="/shop">
              <Button>العودة إلى المتجر</Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pt-20">
      <div className="container max-w-4xl mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8">سلة المشتريات</h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* قائمة المنتجات */}
          <div className="lg:col-span-2 space-y-4">
            {items.map((item) => (
              <Card key={item.id} className="p-4">
                <div className="flex gap-4">
                  {item.image && (
                    <img
                      src={item.image}
                      alt={item.title}
                      className="w-24 h-24 rounded-lg object-cover"
                    />
                  )}
                  <div className="flex-1">
                    <h3 className="font-semibold text-lg mb-2">{item.title}</h3>
                    <p className="text-primary font-bold mb-4">${item.price}</p>

                    {/* التحكم في الكمية */}
                    <div className="flex items-center gap-2 mb-4">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() =>
                          updateQuantity(item.id, item.quantity - 1)
                        }
                      >
                        <Minus className="w-4 h-4" />
                      </Button>
                      <span className="w-8 text-center font-semibold">
                        {item.quantity}
                      </span>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() =>
                          updateQuantity(item.id, item.quantity + 1)
                        }
                      >
                        <Plus className="w-4 h-4" />
                      </Button>
                    </div>

                    {/* السعر الإجمالي للمنتج */}
                    <p className="text-sm text-muted-foreground mb-4">
                      الإجمالي: ${(parseFloat(item.price) * item.quantity).toFixed(2)}
                    </p>

                    {/* زر الحذف */}
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => removeFromCart(item.id)}
                    >
                      <Trash2 className="w-4 h-4 mr-2" />
                      حذف
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>

          {/* ملخص الطلب */}
          <div className="lg:col-span-1">
            <Card className="p-6 sticky top-24">
              <h2 className="text-xl font-bold mb-4">ملخص الطلب</h2>

              <div className="space-y-3 mb-6 pb-6 border-b">
                <div className="flex justify-between">
                  <span>عدد المنتجات:</span>
                  <span className="font-semibold">{items.length}</span>
                </div>
                <div className="flex justify-between">
                  <span>الكمية الإجمالية:</span>
                  <span className="font-semibold">
                    {items.reduce((sum, item) => sum + item.quantity, 0)}
                  </span>
                </div>
              </div>

              <div className="flex justify-between items-center mb-6 text-lg font-bold">
                <span>الإجمالي:</span>
                <span className="text-primary">${total.toFixed(2)}</span>
              </div>

              <Button className="w-full mb-3" size="lg">
                متابعة الدفع
              </Button>

              <Button
                variant="outline"
                className="w-full mb-3"
                onClick={clearCart}
              >
                إفراغ السلة
              </Button>

              <Link href="/shop">
                <Button variant="ghost" className="w-full">
                  العودة للتسوق
                </Button>
              </Link>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
