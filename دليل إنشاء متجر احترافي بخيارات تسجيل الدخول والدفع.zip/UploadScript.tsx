import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Upload, FileText, Code2, AlertCircle } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";

export default function UploadScript() {
  const { isAuthenticated, user } = useAuth();
  const [, setLocation] = useLocation();
  const [scriptName, setScriptName] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const [category, setCategory] = useState("");
  const [scriptContent, setScriptContent] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  if (!isAuthenticated) {
    return (
      <div className="container py-20">
        <Card className="p-8 bg-yellow-50 border-yellow-200">
          <div className="flex items-start gap-4">
            <AlertCircle className="w-6 h-6 text-yellow-600 flex-shrink-0 mt-1" />
            <div>
              <h2 className="text-lg font-bold text-yellow-900 mb-2">
                يجب تسجيل الدخول أولاً
              </h2>
              <p className="text-yellow-800 mb-4">
                يرجى تسجيل الدخول لرفع السكربتات
              </p>
              <Button
                onClick={() => setLocation("/auth")}
                className="bg-yellow-600 hover:bg-yellow-700"
              >
                تسجيل الدخول
              </Button>
            </div>
          </div>
        </Card>
      </div>
    );
  }

  const uploadMutation = trpc.scripts.upload.useMutation({
    onSuccess: () => {
      toast.success("تم رفع السكربت بنجاح!");
      setScriptName("");
      setDescription("");
      setPrice("");
      setCategory("");
      setScriptContent("");
      setLocation("/dashboard");
    },
    onError: (error) => {
      toast.error(error.message || "حدث خطأ أثناء رفع السكربت");
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!scriptName || !description || !price || !category || !scriptContent) {
      toast.error("يرجى ملء جميع الحقول");
      return;
    }

    setIsLoading(true);
    try {
      await uploadMutation.mutateAsync({
        name: scriptName,
        description,
        price: parseFloat(price),
        category,
        content: scriptContent,
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background py-12 px-4">
      <div className="container max-w-2xl">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-foreground mb-2">
            رفع سكربت جديد
          </h1>
          <p className="text-muted-foreground">
            شارك سكربتك مع المجتمع وابدأ في جني الأرباح
          </p>
        </div>

        <Card className="p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Script Name */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                اسم السكربت
              </label>
              <Input
                type="text"
                placeholder="مثال: نظام الدفع المتقدم"
                value={scriptName}
                onChange={(e) => setScriptName(e.target.value)}
                className="w-full"
              />
            </div>

            {/* Description */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                الوصف
              </label>
              <textarea
                placeholder="اكتب وصفاً مفصلاً للسكربت..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full p-3 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-accent"
                rows={4}
              />
            </div>

            {/* Category */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                الفئة
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full p-3 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-accent"
              >
                <option value="">اختر فئة</option>
                <option value="game">ألعاب</option>
                <option value="utility">أدوات</option>
                <option value="framework">إطار عمل</option>
                <option value="library">مكتبة</option>
                <option value="other">أخرى</option>
              </select>
            </div>

            {/* Price */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                السعر (SAR)
              </label>
              <Input
                type="number"
                placeholder="0.00"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                min="0"
                step="0.01"
                className="w-full"
              />
            </div>

            {/* Script Content */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                محتوى السكربت
              </label>
              <textarea
                placeholder="الصق كود السكربت هنا..."
                value={scriptContent}
                onChange={(e) => setScriptContent(e.target.value)}
                className="w-full p-3 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-accent font-mono text-sm"
                rows={10}
              />
            </div>

            {/* Submit Button */}
            <Button
              type="submit"
              disabled={isLoading}
              className="w-full bg-accent hover:bg-accent/90 flex items-center justify-center gap-2"
            >
              <Upload className="w-4 h-4" />
              {isLoading ? "جاري الرفع..." : "رفع السكربت"}
            </Button>
          </form>
        </Card>

        {/* Info Box */}
        <Card className="mt-8 p-6 bg-blue-50 border-blue-200">
          <h3 className="font-bold text-blue-900 mb-3">ملاحظات مهمة:</h3>
          <ul className="space-y-2 text-sm text-blue-800">
            <li>✓ تأكد من أن السكربت يعمل بشكل صحيح قبل الرفع</li>
            <li>✓ اكتب وصفاً واضحاً ومفصلاً</li>
            <li>✓ حدد السعر المناسب</li>
            <li>✓ سيتم مراجعة السكربت قبل نشره</li>
          </ul>
        </Card>
      </div>
    </div>
  );
}
