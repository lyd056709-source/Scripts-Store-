import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import Navbar from "@/components/Navbar";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { CartProvider } from "./contexts/CartContext";
import Home from "./pages/Home";
import Shop from "./pages/Shop";
import ScriptDetail from "./pages/ScriptDetail";
import Dashboard from "./pages/Dashboard";
import AdminScripts from "./pages/AdminScripts";
import Cart from "./pages/Cart";
import Auth from "./pages/Auth";
import WhatsNew from "./pages/WhatsNew";
import UploadScript from "./pages/UploadScript";
import CreateTicket from "./pages/CreateTicket";
import AIScriptWriter from "./pages/AIScriptWriter";

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/auth"} component={Auth} />
      <Route path={"/whats-new"} component={WhatsNew} />
      <Route path={"/upload"} component={UploadScript} />
      <Route path={"/ticket"} component={CreateTicket} />
      <Route path={"/ai-writer"} component={AIScriptWriter} />
      <Route path={"/shop"} component={Shop} />
      <Route path={"/cart"} component={Cart} />
      <Route path={"/dashboard"} component={Dashboard} />
      <Route path={"/admin/scripts"} component={AdminScripts} />
      <Route path={"/:id"} component={ScriptDetail} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
        switchable={true}
      >
        <CartProvider>
          <TooltipProvider>
            <Navbar />
            <Toaster />
            <Router />
          </TooltipProvider>
        </CartProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
