import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Download, ShoppingBag, TicketIcon, Settings } from "lucide-react";
import { useLocation } from "wouter";

export default function Dashboard() {
  const { user, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  // Redirect if not authenticated
  if (!isAuthenticated) {
    setLocation("/");
    return null;
  }

  const { data: orders = [] } = trpc.orders.getMyOrders.useQuery();
  const { data: tickets = [] } = trpc.tickets.getMyTickets.useQuery();

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted">
      {/* Header */}
      <div className="bg-background/80 backdrop-blur-md border-b border-border">
        <div className="container py-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold mb-2">لوحة التحكم</h1>
              <p className="text-muted-foreground">مرحباً {user?.name}</p>
            </div>
            <div className="w-12 h-12 rounded-full bg-accent/20 flex items-center justify-center">
              {user?.avatar ? (
                <img src={user.avatar} alt={user.name || "User"} className="w-full h-full rounded-full" />
              ) : (
                <span className="text-xl font-bold text-accent">{user?.name?.charAt(0) || "U"}</span>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container py-12">
        <Tabs defaultValue="purchases" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="purchases" className="gap-2">
              <ShoppingBag className="w-4 h-4" />
              المشتريات
            </TabsTrigger>
            <TabsTrigger value="downloads" className="gap-2">
              <Download className="w-4 h-4" />
              التحميلات
            </TabsTrigger>
            <TabsTrigger value="support" className="gap-2">
              <TicketIcon className="w-4 h-4" />
              الدعم الفني
            </TabsTrigger>
          </TabsList>

          {/* Purchases Tab */}
          <TabsContent value="purchases" className="space-y-4">
            <div className="grid md:grid-cols-2 gap-6">
              {orders.length === 0 ? (
                <Card className="card-elegant md:col-span-2 text-center py-12">
                  <ShoppingBag className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                  <p className="text-lg text-muted-foreground">لم تقم بأي عمليات شراء بعد</p>
                  <Button className="mt-4 bg-accent hover:bg-accent/90">
                    ابدأ التسوق الآن
                  </Button>
                </Card>
              ) : (
                orders.map((order) => (
                  <Card key={order.id} className="card-elegant">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <h3 className="font-bold">الطلب #{order.id}</h3>
                        <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                          order.status === "completed"
                            ? "bg-green-100 text-green-700"
                            : order.status === "pending"
                            ? "bg-yellow-100 text-yellow-700"
                            : "bg-red-100 text-red-700"
                        }`}>
                          {order.status === "completed" && "مكتمل"}
                          {order.status === "pending" && "قيد الانتظار"}
                          {order.status === "failed" && "فشل"}
                          {order.status === "refunded" && "مرتجع"}
                        </span>
                      </div>
                      <div className="space-y-2 text-sm">
                        <p className="text-muted-foreground">
                          التاريخ: {new Date(order.createdAt).toLocaleDateString("ar-SA")}
                        </p>
                        <p className="font-bold text-lg">
                          ${parseFloat(order.totalPrice).toFixed(2)}
                        </p>
                      </div>
                      <Button variant="outline" className="w-full">
                        عرض التفاصيل
                      </Button>
                    </div>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>

          {/* Downloads Tab */}
          <TabsContent value="downloads" className="space-y-4">
            <Card className="card-elegant">
              <div className="space-y-4">
                <h3 className="font-bold text-lg">السكربتات المتاحة للتحميل</h3>
                <div className="space-y-3">
                  {orders.length === 0 ? (
                    <p className="text-muted-foreground text-center py-8">
                      لا توجد سكربتات متاحة للتحميل
                    </p>
                  ) : (
                    <div className="space-y-3">
                      {/* Placeholder for downloads */}
                      <div className="p-4 border border-border rounded-lg flex items-center justify-between">
                        <div>
                          <p className="font-medium">Script Name</p>
                          <p className="text-sm text-muted-foreground">v1.0.0</p>
                        </div>
                        <Button size="sm" className="gap-2">
                          <Download className="w-4 h-4" />
                          تحميل
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </Card>
          </TabsContent>

          {/* Support Tab */}
          <TabsContent value="support" className="space-y-4">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold">تذاكر الدعم الفني</h2>
              <Button className="bg-accent hover:bg-accent/90">
                <TicketIcon className="w-4 h-4 mr-2" />
                إنشاء تذكرة جديدة
              </Button>
            </div>

            <div className="grid gap-4">
              {tickets.length === 0 ? (
                <Card className="card-elegant text-center py-12">
                  <TicketIcon className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                  <p className="text-lg text-muted-foreground">لا توجد تذاكر دعم</p>
                </Card>
              ) : (
                tickets.map((ticket) => (
                  <Card key={ticket.id} className="card-elegant">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <h3 className="font-bold mb-1">{ticket.subject}</h3>
                        <p className="text-sm text-muted-foreground mb-2">
                          {ticket.description}
                        </p>
                        <div className="flex gap-2">
                          <span className={`text-xs px-2 py-1 rounded ${
                            ticket.status === "open"
                              ? "bg-blue-100 text-blue-700"
                              : ticket.status === "in_progress"
                              ? "bg-yellow-100 text-yellow-700"
                              : "bg-green-100 text-green-700"
                          }`}>
                            {ticket.status === "open" && "مفتوح"}
                            {ticket.status === "in_progress" && "قيد المعالجة"}
                            {ticket.status === "resolved" && "محل"}
                            {ticket.status === "closed" && "مغلق"}
                          </span>
                          <span className="text-xs px-2 py-1 rounded bg-muted">
                            {ticket.priority === "low" && "منخفض"}
                            {ticket.priority === "medium" && "متوسط"}
                            {ticket.priority === "high" && "عالي"}
                          </span>
                        </div>
                      </div>
                      <Button variant="outline" size="sm">
                        عرض
                      </Button>
                    </div>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
