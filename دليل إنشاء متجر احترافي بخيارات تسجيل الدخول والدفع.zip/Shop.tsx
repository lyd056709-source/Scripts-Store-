import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/_core/hooks/useAuth";
import { useCart } from "@/contexts/CartContext";
import { ShoppingCart, Star, Search, Filter, Zap } from "lucide-react";
import { Link } from "wouter";
import { toast } from "sonner";

export default function Shop() {
  const { user, isAuthenticated } = useAuth();
  const { addToCart } = useCart();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [sortBy, setSortBy] = useState("newest");

  const { data: scripts = [], isLoading } = trpc.scripts.list.useQuery();

  const categories = useMemo(() => {
    const cats = new Set(scripts.map((s) => s.category));
    return Array.from(cats);
  }, [scripts]);

  const filteredScripts = useMemo(() => {
    let filtered = scripts;

    if (searchQuery) {
      filtered = filtered.filter(
        (s) =>
          s.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          s.description?.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    if (selectedCategory !== "all") {
      filtered = filtered.filter((s) => s.category === selectedCategory);
    }

    // Sort
    if (sortBy === "newest") {
      filtered = [...filtered].sort(
        (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );
    } else if (sortBy === "popular") {
      filtered = [...filtered].sort((a, b) => (b.downloads || 0) - (a.downloads || 0));
    } else if (sortBy === "rating") {
      filtered = [...filtered].sort((a, b) => parseFloat(b.rating || "0") - parseFloat(a.rating || "0"));
    } else if (sortBy === "price-low") {
      filtered = [...filtered].sort((a, b) => parseFloat(a.price) - parseFloat(b.price));
    } else if (sortBy === "price-high") {
      filtered = [...filtered].sort((a, b) => parseFloat(b.price) - parseFloat(a.price));
    }

    return filtered;
  }, [scripts, searchQuery, selectedCategory, sortBy]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted">
      {/* Header */}
      <div className="bg-background/80 backdrop-blur-md border-b border-border sticky top-16 z-40">
        <div className="container py-8">
          <h1 className="text-4xl font-bold mb-6">متجر السكربتات</h1>

          {/* Search Bar */}
          <div className="relative mb-6">
            <Search className="absolute left-3 top-3 w-5 h-5 text-muted-foreground" />
            <Input
              placeholder="ابحث عن السكربتات..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>

          {/* Filters */}
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <label className="text-sm font-medium text-muted-foreground mb-2 block">
                الفئة
              </label>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full px-4 py-2 rounded-lg border border-border bg-background text-foreground"
              >
                <option value="all">جميع الفئات</option>
                {categories.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex-1">
              <label className="text-sm font-medium text-muted-foreground mb-2 block">
                الترتيب
              </label>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="w-full px-4 py-2 rounded-lg border border-border bg-background text-foreground"
              >
                <option value="newest">الأحدث</option>
                <option value="popular">الأكثر تحميلاً</option>
                <option value="rating">الأعلى تقييماً</option>
                <option value="price-low">السعر: من الأقل للأعلى</option>
                <option value="price-high">السعر: من الأعلى للأقل</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Scripts Grid */}
      <div className="container py-12">
        {isLoading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <Card key={i} className="h-64 animate-pulse bg-muted" />
            ))}
          </div>
        ) : filteredScripts.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-lg text-muted-foreground">لم يتم العثور على سكربتات</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredScripts.map((script) => (
              <Link key={script.id} href={`/script/${script.id}`}>
                <Card className="card-elegant cursor-pointer group overflow-hidden">
                  {/* Image */}
                  {script.image && (
                    <div className="mb-4 h-40 bg-muted rounded-lg overflow-hidden">
                      <img
                        src={script.image}
                        alt={script.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                  )}

                  {/* Content */}
                  <div className="space-y-3">
                    <h3 className="font-bold text-lg line-clamp-2">{script.title}</h3>

                    <p className="text-sm text-muted-foreground line-clamp-2">
                      {script.description}
                    </p>

                    {/* Rating */}
                    {script.rating && (
                      <div className="flex items-center gap-2">
                        <div className="flex items-center gap-1">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`w-4 h-4 ${
                                i < Math.round(parseFloat(script.rating || "0"))
                                  ? "fill-accent text-accent"
                                  : "text-muted"
                              }`}
                            />
                          ))}
                        </div>
                        <span className="text-sm text-muted-foreground">
                          ({script.reviewCount})
                        </span>
                      </div>
                    )}

                    {/* Footer */}
                    <div className="flex flex-col gap-2 pt-4 border-t border-border">
                      <div className="flex items-center justify-between">
                        <div className="text-2xl font-bold text-accent">
                          ${parseFloat(script.price).toFixed(2)}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          className="flex-1 gap-2 bg-accent hover:bg-accent/90"
                          onClick={(e) => {
                            e.preventDefault();
                            if (isAuthenticated) {
                              addToCart({
                                id: script.id,
                                title: script.title,
                                price: script.price,
                                image: script.image || undefined,
                              });
                              toast.success(`تمت إضافة ${script.title} إلى السلة`);
                            } else {
                              toast.error("يجب تسجيل الدخول أولاً");
                            }
                          }}
                        >
                          <Zap className="w-4 h-4" />
                          شراء الآن
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="gap-2"
                          onClick={(e) => {
                            e.preventDefault();
                            addToCart({
                              id: script.id,
                              title: script.title,
                              price: script.price,
                              image: script.image || undefined,
                            });
                            toast.success(`تمت إضافة ${script.title} إلى السلة`);
                          }}
                        >
                          <ShoppingCart className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>

                    {/* Meta */}
                    <div className="flex items-center justify-between text-xs text-muted-foreground pt-2">
                      <span>{script.downloads} تحميل</span>
                      <span className="bg-accent/10 text-accent px-2 py-1 rounded">
                        {script.category}
                      </span>
                    </div>
                  </div>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
