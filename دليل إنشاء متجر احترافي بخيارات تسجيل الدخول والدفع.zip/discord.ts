import { ENV } from "./env";

interface DiscordUser {
  id: string;
  username: string;
  avatar: string | null;
  email: string;
}

interface DiscordTokenResponse {
  access_token: string;
  token_type: string;
  expires_in: number;
  refresh_token: string;
  scope: string;
}

/**
 * Get Discord authorization URL
 */
export function getDiscordAuthUrl(redirectUri: string): string {
  const params = new URLSearchParams({
    client_id: ENV.discordClientId,
    redirect_uri: redirectUri,
    response_type: "code",
    scope: "identify email",
  });

  return `https://discord.com/api/oauth2/authorize?${params.toString()}`;
}

/**
 * Exchange Discord authorization code for access token
 */
export async function exchangeDiscordCode(
  code: string,
  redirectUri: string
): Promise<DiscordTokenResponse> {
  try {
    const response = await fetch("https://discord.com/api/oauth2/token", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: new URLSearchParams({
        client_id: ENV.discordClientId,
        client_secret: ENV.discordClientSecret,
        code,
        grant_type: "authorization_code",
        redirect_uri: redirectUri,
      }).toString(),
    });

    if (!response.ok) {
      const errorData = await response.text();
      console.error("[Discord] Token exchange error response:", errorData);
      throw new Error(`Discord token exchange failed: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error("[Discord] Token exchange error:", error);
    throw error;
  }
}

/**
 * Get Discord user information using access token
 */
export async function getDiscordUser(accessToken: string): Promise<DiscordUser> {
  const response = await fetch("https://discord.com/api/users/@me", {
    headers: {
      Authorization: `Bearer ${accessToken}`,
    },
  });

  if (!response.ok) {
    throw new Error(`Failed to fetch Discord user: ${response.statusText}`);
  }

  const user = await response.json();

  return {
    id: user.id,
    username: user.username,
    avatar: user.avatar,
    email: user.email,
  };
}

/**
 * Get Discord user avatar URL
 */
export function getDiscordAvatarUrl(userId: string, avatar: string | null): string {
  if (!avatar) {
    return `https://cdn.discordapp.com/embed/avatars/${parseInt(userId) % 5}.png`;
  }

  const format = avatar.startsWith("a_") ? "gif" : "png";
  return `https://cdn.discordapp.com/avatars/${userId}/${avatar}.${format}`;
}
