import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Mail, Code2 } from "lucide-react";
import { getDiscordLoginUrl } from "@/const";

export default function Auth() {
  const [, setLocation] = useLocation();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isSignUp, setIsSignUp] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const loginMutation = trpc.auth.loginWithEmail.useMutation({
    onSuccess: () => {
      toast.success(isSignUp ? "تم التسجيل بنجاح!" : "تم تسجيل الدخول بنجاح!");
      setLocation("/");
    },
    onError: (error: any) => {
      toast.error(error?.message || "حدث خطأ ما");
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      toast.error("يرجى ملء جميع الحقول");
      return;
    }

    setIsLoading(true);
    try {
      await loginMutation.mutateAsync({
        email,
        password,
        isSignUp,
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background via-background to-accent/10 px-4">
      <Card className="w-full max-w-md p-8 border-border/50 backdrop-blur-sm">
        {/* Header */}
        <div className="flex items-center justify-center gap-2 mb-8">
          <Code2 className="w-8 h-8 text-accent" />
          <h1 className="text-2xl font-bold text-foreground">Scripts Store</h1>
        </div>

        <h2 className="text-xl font-bold text-center mb-2 text-foreground">
          {isSignUp ? "إنشاء حساب جديد" : "تسجيل الدخول"}
        </h2>
        <p className="text-sm text-muted-foreground text-center mb-6">
          {isSignUp
            ? "أنشئ حساباً للوصول إلى المتجر"
            : "سجل دخولك للمتابعة"}
        </p>

        {/* Email/Password Form */}
        <form onSubmit={handleSubmit} className="space-y-4 mb-6">
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">
              البريد الإلكتروني
            </label>
            <Input
              type="email"
              placeholder="your@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              disabled={isLoading}
              className="w-full"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground mb-2">
              كلمة المرور
            </label>
            <Input
              type="password"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              disabled={isLoading}
              className="w-full"
            />
          </div>

          <Button
            type="submit"
            disabled={isLoading}
            className="w-full bg-accent hover:bg-accent/90"
          >
            <Mail className="w-4 h-4 ml-2" />
            {isLoading
              ? "جاري المعالجة..."
              : isSignUp
                ? "إنشاء حساب"
                : "تسجيل الدخول"}
          </Button>
        </form>

        {/* Divider */}
        <div className="relative mb-6">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-border"></div>
          </div>
          <div className="relative flex justify-center text-sm">
            <span className="px-2 bg-background text-muted-foreground">أو</span>
          </div>
        </div>

        {/* Discord Login */}
        <a href={getDiscordLoginUrl()} className="block mb-4">
          <Button
            type="button"
            variant="outline"
            className="w-full border-border hover:bg-muted"
          >
            <svg
              className="w-4 h-4 ml-2"
              fill="currentColor"
              viewBox="0 0 24 24"
            >
              <path d="M20.317 4.37a19.791 19.791 0 00-4.885-1.515a.074.074 0 00-.079.037c-.211.375-.444.864-.607 1.25a18.27 18.27 0 00-5.487 0c-.163-.386-.395-.875-.607-1.25a.077.077 0 00-.079-.037A19.736 19.736 0 003.677 4.37a.07.07 0 00-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 00.031.057 19.9 19.9 0 005.993 3.03.078.078 0 00.084-.028c.462-.63.874-1.295 1.226-1.994a.076.076 0 00-.042-.106c-.658-.249-1.282-.578-1.855-.953a.077.077 0 00-.009-.128c.124-.093.248-.19.368-.287a.074.074 0 00.076-.01c3.89 1.817 8.109 1.817 11.967 0a.075.075 0 00.076.009c.12.098.244.194.369.288a.077.077 0 00-.006.127c-.573.375-1.197.704-1.856.953a.077.077 0 00-.041.107c.352.699.764 1.364 1.225 1.994a.076.076 0 00.084.028 19.963 19.963 0 006.002-3.03.077.077 0 00.032-.057c.5-4.506-.838-8.962-3.552-12.66a.06.06 0 00-.031-.03zM8.02 15.33c-1.183 0-2.157-.965-2.157-2.156c0-1.193.964-2.157 2.157-2.157c1.193 0 2.156.964 2.157 2.157c0 1.19-.964 2.156-2.157 2.156zm7.975 0c-1.183 0-2.157-.965-2.157-2.156c0-1.193.964-2.157 2.157-2.157c1.193 0 2.156.964 2.157 2.157c0 1.19-.964 2.156-2.157 2.156z" />
            </svg>
            تسجيل الدخول عبر Discord
          </Button>
        </a>

        {/* Toggle */}
        <p className="text-center text-sm text-muted-foreground">
          {isSignUp ? "هل لديك حساب بالفعل؟" : "ليس لديك حساب؟"}{" "}
          <button
            onClick={() => setIsSignUp(!isSignUp)}
            className="text-accent hover:underline font-medium"
          >
            {isSignUp ? "تسجيل الدخول" : "إنشاء حساب"}
          </button>
        </p>
      </Card>
    </div>
  );
}
