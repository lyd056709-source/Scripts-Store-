import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { AlertCircle, Send } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";

export default function CreateTicket() {
  const { isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const [subject, setSubject] = useState("");
  const [description, setDescription] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  if (!isAuthenticated) {
    return (
      <div className="container py-20">
        <Card className="p-8 bg-yellow-50 border-yellow-200">
          <div className="flex items-start gap-4">
            <AlertCircle className="w-6 h-6 text-yellow-600 flex-shrink-0 mt-1" />
            <div>
              <h2 className="text-lg font-bold text-yellow-900 mb-2">
                يجب تسجيل الدخول أولاً
              </h2>
              <p className="text-yellow-800 mb-4">
                يرجى تسجيل الدخول لإنشاء تذكرة دعم
              </p>
              <Button
                onClick={() => setLocation("/auth")}
                className="bg-yellow-600 hover:bg-yellow-700"
              >
                تسجيل الدخول
              </Button>
            </div>
          </div>
        </Card>
      </div>
    );
  }

  const createTicketMutation = trpc.tickets.createTicket.useMutation({
    onSuccess: () => {
      toast.success("تم إنشاء التذكرة بنجاح!");
      setSubject("");
      setDescription("");
      setLocation("/dashboard");
    },
    onError: (error: any) => {
      toast.error(error.message || "حدث خطأ أثناء إنشاء التذكرة");
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!subject || !description) {
      toast.error("يرجى ملء جميع الحقول");
      return;
    }

    setIsLoading(true);
    try {
      await createTicketMutation.mutateAsync({
        subject,
        description,
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background py-12 px-4">
      <div className="container max-w-2xl">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-foreground mb-2">
            إنشاء تذكرة دعم جديدة
          </h1>
          <p className="text-muted-foreground">
            اتصل بفريق الدعم الفني لحل مشاكلك
          </p>
        </div>

        <Card className="p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Subject */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                الموضوع
              </label>
              <Input
                type="text"
                placeholder="مثال: مشكلة في التحميل"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                className="w-full"
              />
            </div>

            {/* Description */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                الوصف
              </label>
              <textarea
                placeholder="اشرح المشكلة بالتفصيل..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full p-3 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-accent"
                rows={6}
              />
            </div>

            {/* Submit Button */}
            <Button
              type="submit"
              disabled={isLoading}
              className="w-full bg-accent hover:bg-accent/90 flex items-center justify-center gap-2"
            >
              <Send className="w-4 h-4" />
              {isLoading ? "جاري الإرسال..." : "إرسال التذكرة"}
            </Button>
          </form>
        </Card>

        {/* Info Box */}
        <Card className="mt-8 p-6 bg-blue-50 border-blue-200">
          <h3 className="font-bold text-blue-900 mb-3">معلومات مهمة:</h3>
          <ul className="space-y-2 text-sm text-blue-800">
            <li>✓ سيتم الرد على تذكرتك خلال 24 ساعة</li>
            <li>✓ تأكد من شرح المشكلة بوضوح</li>
            <li>✓ يمكنك متابعة حالة التذكرة من لوحة التحكم</li>
            <li>✓ سيتم إرسال إشعار عند الرد على تذكرتك</li>
          </ul>
        </Card>
      </div>
    </div>
  );
}
