import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import {
  Mail,
  MessageCircle,
  Zap,
  Shield,
  Users,
  TrendingUp,
  CheckCircle2,
  ArrowRight,
} from "lucide-react";

export default function WhatsNew() {
  const features = [
    {
      icon: Mail,
      title: "تسجيل دخول عبر Gmail",
      description: "سجل دخولك مباشرة باستخدام حسابك على Gmail بدون الحاجة لإنشاء حساب جديد",
      date: "مارس 2026",
      badge: "جديد",
    },
    {
      icon: MessageCircle,
      title: "نظام الدعم الفني المحسّن",
      description: "تواصل مع فريق الدعم عبر Discord للحصول على مساعدة فورية 24/7",
      date: "مارس 2026",
      badge: "محدث",
    },
    {
      icon: Zap,
      title: "تسريع الأداء",
      description: "تحسينات في سرعة التحميل والأداء العام للموقع بنسبة 40%",
      date: "مارس 2026",
      badge: "محسّن",
    },
    {
      icon: Shield,
      title: "أمان محسّن",
      description: "تشفير قوي وحماية متقدمة لبيانات المستخدمين والمعاملات",
      date: "مارس 2026",
      badge: "آمن",
    },
    {
      icon: Users,
      title: "ملفات شخصية محسّنة",
      description: "واجهة مستخدم محسّنة لإدارة حسابك والمشتريات والتنزيلات",
      date: "مارس 2026",
      badge: "جديد",
    },
    {
      icon: TrendingUp,
      title: "إحصائيات وتقارير",
      description: "عرض مفصل لإحصائيات المشتريات والتنزيلات والتقييمات",
      date: "مارس 2026",
      badge: "جديد",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header Section */}
      <div className="bg-gradient-to-br from-accent/10 via-background to-background py-16 px-4">
        <div className="container max-w-4xl mx-auto">
          <div className="text-center">
            <Badge className="mb-4 bg-accent/20 text-accent hover:bg-accent/30">
              ما الجديد
            </Badge>
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
              أحدث الميزات والتحديثات
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              اكتشف جميع الإضافات الجديدة والتحسينات التي أضفناها إلى Scripts Store
            </p>
          </div>
        </div>
      </div>

      {/* Features Grid */}
      <div className="container max-w-5xl mx-auto py-16 px-4">
        <div className="grid md:grid-cols-2 gap-6 mb-12">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <Card
                key={index}
                className="p-6 border-border/50 hover:border-accent/50 transition-all duration-300 hover:shadow-lg"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-accent/10 rounded-lg">
                      <Icon className="w-6 h-6 text-accent" />
                    </div>
                    <h3 className="text-lg font-bold text-foreground">
                      {feature.title}
                    </h3>
                  </div>
                  <Badge variant="secondary" className="text-xs">
                    {feature.badge}
                  </Badge>
                </div>

                <p className="text-sm text-muted-foreground mb-4">
                  {feature.description}
                </p>

                <p className="text-xs text-muted-foreground/60">
                  {feature.date}
                </p>
              </Card>
            );
          })}
        </div>

        {/* CTA Section */}
        <Card className="p-8 bg-gradient-to-r from-accent/10 to-accent/5 border-accent/20">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <h2 className="text-2xl font-bold text-foreground mb-2">
                جاهز للبدء؟
              </h2>
              <p className="text-muted-foreground">
                استكشف جميع السكربتات والأدوات المتاحة في متجرنا
              </p>
            </div>
            <Link href="/shop">
              <Button className="bg-accent hover:bg-accent/90 flex items-center gap-2 whitespace-nowrap">
                اذهب إلى المتجر
                <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
          </div>
        </Card>

        {/* Changelog Section */}
        <div className="mt-16">
          <h2 className="text-2xl font-bold text-foreground mb-8">
            سجل التغييرات
          </h2>

          <div className="space-y-6">
            {/* Version 1.2.0 */}
            <Card className="p-6 border-border/50">
              <div className="flex items-start gap-4">
                <div className="p-2 bg-green-500/10 rounded-lg mt-1">
                  <CheckCircle2 className="w-5 h-5 text-green-500" />
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-foreground mb-2">
                    الإصدار 1.2.0 - مارس 6، 2026
                  </h3>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 bg-accent rounded-full"></span>
                      إضافة تسجيل دخول عبر Gmail
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 bg-accent rounded-full"></span>
                      تحسينات في الأداء والسرعة
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 bg-accent rounded-full"></span>
                      إصلاح الأخطاء والمشاكل المعروفة
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 bg-accent rounded-full"></span>
                      تحسينات في واجهة المستخدم
                    </li>
                  </ul>
                </div>
              </div>
            </Card>

            {/* Version 1.1.0 */}
            <Card className="p-6 border-border/50">
              <div className="flex items-start gap-4">
                <div className="p-2 bg-blue-500/10 rounded-lg mt-1">
                  <CheckCircle2 className="w-5 h-5 text-blue-500" />
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-foreground mb-2">
                    الإصدار 1.1.0 - مارس 1، 2026
                  </h3>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 bg-accent rounded-full"></span>
                      إطلاق النسخة الأولى من Scripts Store
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 bg-accent rounded-full"></span>
                      نظام الدعم الفني عبر Discord
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 bg-accent rounded-full"></span>
                      واجهة مستخدم حديثة وسهلة الاستخدام
                    </li>
                  </ul>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
