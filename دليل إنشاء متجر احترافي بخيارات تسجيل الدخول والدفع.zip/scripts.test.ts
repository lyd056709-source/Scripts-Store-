import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

function createAuthContext(userId: number = 1): TrpcContext {
  const user: AuthenticatedUser = {
    id: userId,
    openId: "sample-user",
    email: "sample@example.com",
    name: "Sample User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

describe("Scripts Router", () => {
  describe("scripts.list", () => {
    it("returns list of active scripts", async () => {
      const ctx = createPublicContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.scripts.list();

      expect(Array.isArray(result)).toBe(true);
    });
  });

  describe("scripts.getById", () => {
    it("returns script by id or undefined if not found", async () => {
      const ctx = createPublicContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.scripts.getById({ id: 1 });

      // Script may or may not exist in test database, so we check if it's either undefined or has the correct id
      expect(result === undefined || result?.id === 1).toBe(true);
    });
  });


  describe("scripts.getReviews", () => {
    it("returns reviews for a script", async () => {
      const ctx = createPublicContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.scripts.getReviews({ scriptId: 1 });

      expect(Array.isArray(result)).toBe(true);
    });
  });
});

describe("Cart Router", () => {
  describe("cart.getCart", () => {
    it("returns user cart items", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.cart.getCart();

      expect(Array.isArray(result)).toBe(true);
    });
  });

  describe("cart.addToCart", () => {
    it("adds item to cart", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.cart.addToCart({ scriptId: 1, quantity: 1 });

      expect(result.success).toBe(true);
    });
  });
});

describe("Orders Router", () => {
  describe("orders.getMyOrders", () => {
    it("returns user orders", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.orders.getMyOrders();

      expect(Array.isArray(result)).toBe(true);
    });
  });

  describe("orders.createOrder", () => {
    it("creates a new order", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.orders.createOrder({
        items: [{ scriptId: 1, price: 29.99 }],
      });

      expect(result.success).toBe(true);
      expect(result.orderId).toBeDefined();
    });
  });
});

describe("Support Tickets Router", () => {
  describe("tickets.getMyTickets", () => {
    it("returns user tickets", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.tickets.getMyTickets();

      expect(Array.isArray(result)).toBe(true);
    });
  });

  describe("tickets.createTicket", () => {
    it("creates a new support ticket", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.tickets.createTicket({
        subject: "Test Subject",
        description: "Test Description",
      });

      expect(result.success).toBe(true);
      expect(result.ticketId).toBeDefined();
    });
  });
});
