import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { getLoginUrl } from "@/const";
import { ShoppingCart, Code2, Zap, Shield, Users, TrendingUp } from "lucide-react";
import { Link } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";

export default function Home() {
  const { user, isAuthenticated } = useAuth();

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted">
      {/* Hero Section */}
      <section className="container py-20 md:py-32">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <h1 className="text-5xl md:text-6xl font-bold text-gradient">
                منصة بيع السكربتات الاحترافية
              </h1>
              <p className="text-xl text-muted-foreground">
                اكتشف أفضل السكربتات والأدوات البرمجية من أفضل المطورين. آمنة، موثوقة، واحترافية.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/shop">
                <Button size="lg" className="w-full sm:w-auto bg-accent hover:bg-accent/90">
                  <ShoppingCart className="w-4 h-4 mr-2" />
                  تصفح المتجر
                </Button>
              </Link>
              {!isAuthenticated && (
                <a href={getLoginUrl()}>
                  <Button size="lg" variant="outline" className="w-full sm:w-auto">
                    تسجيل الدخول عبر Discord
                  </Button>
                </a>
              )}
            </div>

            <div className="grid grid-cols-3 gap-4 pt-8">
              <div className="space-y-2">
                <div className="text-2xl font-bold text-accent">500+</div>
                <p className="text-sm text-muted-foreground">سكربت متاح</p>
              </div>
              <div className="space-y-2">
                <div className="text-2xl font-bold text-accent">10K+</div>
                <p className="text-sm text-muted-foreground">عميل راضي</p>
              </div>
              <div className="space-y-2">
                <div className="text-2xl font-bold text-accent">24/7</div>
                <p className="text-sm text-muted-foreground">دعم فني</p>
              </div>
            </div>
          </div>

          <div className="relative h-96 md:h-full">
            <div className="absolute inset-0 bg-gradient-to-br from-accent/20 to-transparent rounded-3xl blur-3xl" />
            <div className="relative bg-card border border-border rounded-3xl p-8" style={{ boxShadow: '0 20px 60px rgba(0, 0, 0, 0.15)' }}>
              <div className="space-y-4">
                <div className="h-12 bg-muted rounded-lg animate-pulse" />
                <div className="space-y-2">
                  <div className="h-4 bg-muted rounded w-3/4 animate-pulse" />
                  <div className="h-4 bg-muted rounded w-1/2 animate-pulse" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-muted/50 py-20">
        <div className="container">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">لماذا Scripts Store؟</h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="card-elegant">
              <div className="flex items-start gap-4">
                <Zap className="w-8 h-8 text-accent flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-bold text-lg mb-2">سرعة عالية</h3>
                  <p className="text-muted-foreground">تحميل فوري وأداء ممتاز</p>
                </div>
              </div>
            </Card>

            <Card className="card-elegant">
              <div className="flex items-start gap-4">
                <Shield className="w-8 h-8 text-accent flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-bold text-lg mb-2">آمن وموثوق</h3>
                  <p className="text-muted-foreground">حماية IP وتشفير كامل</p>
                </div>
              </div>
            </Card>

            <Card className="card-elegant">
              <div className="flex items-start gap-4">
                <Users className="w-8 h-8 text-accent flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-bold text-lg mb-2">دعم 24/7</h3>
                  <p className="text-muted-foreground">فريق دعم متخصص</p>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="container py-20">
        <div className="bg-gradient-to-r from-accent/10 to-accent/5 rounded-3xl p-12 text-center border border-accent/20">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">ابدأ الآن</h2>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
            انضم إلى آلاف المستخدمين الذين يثقون بـ Scripts Store
          </p>
          <Link href="/shop">
            <Button size="lg" className="bg-accent hover:bg-accent/90">
              تصفح المتجر الآن
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
