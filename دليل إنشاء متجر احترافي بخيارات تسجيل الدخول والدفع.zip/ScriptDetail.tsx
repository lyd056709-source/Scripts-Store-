import { useParams } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useCart } from "@/contexts/CartContext";
import { useAuth } from "@/_core/hooks/useAuth";
import { ShoppingCart, Star, Download, ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import { toast } from "sonner";

export default function ScriptDetail() {
  const { id } = useParams<{ id: string }>();
  const { addToCart } = useCart();
  const { isAuthenticated } = useAuth();

  const scriptId = parseInt(id || "0");
  const { data: scripts = [] } = trpc.scripts.list.useQuery();
  const script = scripts.find((s) => s.id === scriptId);

  if (!script) {
    return (
      <div className="min-h-screen bg-background pt-20">
        <div className="container max-w-4xl mx-auto px-4">
          <div className="text-center py-12">
            <h1 className="text-3xl font-bold mb-4">السكربت غير موجود</h1>
            <p className="text-muted-foreground mb-6">
              عذراً، السكربت الذي تبحث عنه غير متوفر
            </p>
            <Link href="/shop">
              <Button>العودة إلى المتجر</Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const handleAddToCart = () => {
    addToCart({
      id: script.id,
      title: script.title,
      price: script.price,
      image: script.image || undefined,
    });
    toast.success(`تمت إضافة ${script.title} إلى السلة`);
  };

  return (
    <div className="min-h-screen bg-background pt-20">
      <div className="container max-w-4xl mx-auto px-4 py-8">
        {/* Back Button */}
        <Link href="/shop">
          <Button variant="ghost" className="mb-6 gap-2">
            <ArrowLeft className="w-4 h-4" />
            العودة إلى المتجر
          </Button>
        </Link>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Image */}
          <div>
            {script.image && (
              <img
                src={script.image}
                alt={script.title}
                className="w-full rounded-lg object-cover"
              />
            )}
            {!script.image && (
              <div className="w-full aspect-square bg-muted rounded-lg flex items-center justify-center">
                <span className="text-muted-foreground">لا توجد صورة</span>
              </div>
            )}
          </div>

          {/* Details */}
          <div className="space-y-6">
            {/* Title and Category */}
            <div>
              <h1 className="text-4xl font-bold mb-2">{script.title}</h1>
              <div className="flex items-center gap-4">
                <span className="bg-accent/10 text-accent px-3 py-1 rounded-full text-sm font-medium">
                  {script.category}
                </span>
                <span className="text-sm text-muted-foreground">
                  الإصدار {script.version}
                </span>
              </div>
            </div>

            {/* Rating */}
            {script.rating && (
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-5 h-5 ${
                        i < Math.round(parseFloat(script.rating || "0"))
                          ? "fill-accent text-accent"
                          : "text-muted"
                      }`}
                    />
                  ))}
                </div>
                <span className="text-sm text-muted-foreground">
                  ({script.reviewCount} تقييم)
                </span>
              </div>
            )}

            {/* Description */}
            <div className="bg-muted/50 p-4 rounded-lg">
              <h3 className="font-semibold mb-2">الوصف</h3>
              <p className="text-muted-foreground leading-relaxed">
                {script.description}
              </p>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 gap-4">
              <Card className="p-4 text-center">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <Download className="w-4 h-4 text-accent" />
                  <span className="text-2xl font-bold">{script.downloads}</span>
                </div>
                <p className="text-sm text-muted-foreground">تحميل</p>
              </Card>
              <Card className="p-4 text-center">
                <div className="text-2xl font-bold mb-2">
                  ${parseFloat(script.price).toFixed(2)}
                </div>
                <p className="text-sm text-muted-foreground">السعر</p>
              </Card>
            </div>

            {/* Price and Action */}
            <div className="border-t border-border pt-6 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-lg font-semibold">السعر الإجمالي:</span>
                <span className="text-3xl font-bold text-accent">
                  ${parseFloat(script.price).toFixed(2)}
                </span>
              </div>

              {isAuthenticated ? (
                <Button
                  size="lg"
                  className="w-full gap-2"
                  onClick={handleAddToCart}
                >
                  <ShoppingCart className="w-5 h-5" />
                  إضافة إلى السلة
                </Button>
              ) : (
                <div className="bg-muted/50 p-4 rounded-lg text-center">
                  <p className="text-sm text-muted-foreground mb-3">
                    يجب تسجيل الدخول لإضافة المنتج إلى السلة
                  </p>
                  <Link href="/">
                    <Button variant="outline" className="w-full">
                      تسجيل الدخول
                    </Button>
                  </Link>
                </div>
              )}

              <Link href="/shop">
                <Button variant="outline" className="w-full">
                  مواصلة التسوق
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
