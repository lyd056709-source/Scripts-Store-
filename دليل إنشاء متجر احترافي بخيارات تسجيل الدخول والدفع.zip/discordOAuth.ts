import { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";
import type { Express, Request, Response } from "express";
import * as db from "../db";
import { getSessionCookieOptions } from "./cookies";
import { sdk } from "./sdk";
import { exchangeDiscordCode, getDiscordUser, getDiscordAvatarUrl } from "./discord";
import { ENV } from "./env";

function getQueryParam(req: Request, key: string): string | undefined {
  const value = req.query[key];
  return typeof value === "string" ? value : undefined;
}

/**
 * Register Discord OAuth routes
 */
export function registerDiscordOAuthRoutes(app: Express) {
  /**
   * Discord OAuth callback endpoint
   * Handles the authorization code exchange and user creation/update
   */
  app.get("/api/discord/callback", async (req: Request, res: Response) => {
    const code = getQueryParam(req, "code");
    const error = getQueryParam(req, "error");
    const state = getQueryParam(req, "state");

    if (error) {
      console.error("[Discord OAuth] Error from Discord:", error);
      res.status(400).json({ error: `Discord authorization error: ${error}` });
      return;
    }

    if (!code) {
      res.status(400).json({ error: "Authorization code is required" });
      return;
    }

    try {
      // Reconstruct redirect_uri from state (encoded origin) or use current request
      let redirectUri = `${req.protocol}://${req.get("host")}/api/discord/callback`;
      
      if (state) {
        try {
          const origin = atob(state);
          redirectUri = `${origin}/api/discord/callback`;
          console.log("[Discord OAuth] Using origin from state:", origin);
        } catch (e) {
          console.log("[Discord OAuth] Failed to decode state, using request protocol/host");
        }
      }

      console.log("[Discord OAuth] Processing callback");
      console.log("[Discord OAuth] Code:", code.substring(0, 10) + "...");
      console.log("[Discord OAuth] Redirect URI:", redirectUri);
      console.log("[Discord OAuth] Client ID:", ENV.discordClientId);

      // Exchange code for access token
      const tokenResponse = await exchangeDiscordCode(code, redirectUri);
      console.log("[Discord OAuth] Token exchange successful");

      // Get user information from Discord
      const discordUser = await getDiscordUser(tokenResponse.access_token);
      console.log("[Discord OAuth] User fetched:", discordUser.id);

      // Get avatar URL
      const avatarUrl = getDiscordAvatarUrl(discordUser.id, discordUser.avatar);

      // Create or update user in database
      console.log("[Discord OAuth] Creating/updating user:", discordUser.id);
      await db.upsertUser({
        openId: `discord_${discordUser.id}`,
        name: discordUser.username || null,
        email: discordUser.email || null,
        loginMethod: "discord",
        lastSignedIn: new Date(),
      });

      // Create session token using Manus SDK
      console.log("[Discord OAuth] Creating session token");
      const sessionToken = await sdk.createSessionToken(`discord_${discordUser.id}`, {
        name: discordUser.username || "",
        expiresInMs: ONE_YEAR_MS,
      });
      console.log("[Discord OAuth] Session token created successfully");

      // Set session cookie
      const cookieOptions = getSessionCookieOptions(req);
      res.cookie(COOKIE_NAME, sessionToken, { ...cookieOptions, maxAge: ONE_YEAR_MS });

      console.log("[Discord OAuth] Login successful, redirecting to home");
      // Redirect to home page
      res.redirect(302, "/");
    } catch (error) {
      console.error("[Discord OAuth] Callback failed", error);
      res.status(500).json({ error: "Discord OAuth callback failed" });
    }
  });
}
