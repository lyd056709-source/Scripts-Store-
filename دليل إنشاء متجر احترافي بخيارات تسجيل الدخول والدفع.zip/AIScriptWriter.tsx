import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { AlertCircle, Sparkles, Copy, Download } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";

export default function AIScriptWriter() {
  const { isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const [prompt, setPrompt] = useState("");
  const [generatedScript, setGeneratedScript] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  if (!isAuthenticated) {
    return (
      <div className="container py-20">
        <Card className="p-8 bg-yellow-50 border-yellow-200">
          <div className="flex items-start gap-4">
            <AlertCircle className="w-6 h-6 text-yellow-600 flex-shrink-0 mt-1" />
            <div>
              <h2 className="text-lg font-bold text-yellow-900 mb-2">
                يجب تسجيل الدخول أولاً
              </h2>
              <p className="text-yellow-800 mb-4">
                يرجى تسجيل الدخول لاستخدام مولد السكربتات بـ AI
              </p>
              <Button
                onClick={() => setLocation("/auth")}
                className="bg-yellow-600 hover:bg-yellow-700"
              >
                تسجيل الدخول
              </Button>
            </div>
          </div>
        </Card>
      </div>
    );
  }

  const generateScriptMutation = trpc.ai.generateScript.useMutation({
    onSuccess: (data: any) => {
      setGeneratedScript(data.script);
      toast.success("تم توليد السكربت بنجاح!");
    },
    onError: (error: any) => {
      toast.error(error.message || "حدث خطأ أثناء توليد السكربت");
    },
  });

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!prompt.trim()) {
      toast.error("يرجى إدخال وصف للسكربت المطلوب");
      return;
    }

    setIsLoading(true);
    try {
      await generateScriptMutation.mutateAsync({ prompt });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(generatedScript);
    toast.success("تم نسخ السكربت!");
  };

  const handleDownload = () => {
    const element = document.createElement("a");
    const file = new Blob([generatedScript], { type: "text/plain" });
    element.href = URL.createObjectURL(file);
    element.download = "script.lua";
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
    toast.success("تم تحميل السكربت!");
  };

  return (
    <div className="min-h-screen bg-background py-12 px-4">
      <div className="container max-w-4xl">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-foreground mb-2 flex items-center gap-2">
            <Sparkles className="w-8 h-8 text-accent" />
            مولد السكربتات بـ AI
          </h1>
          <p className="text-muted-foreground">
            اكتب وصفاً لما تريده، وسيقوم الذكاء الاصطناعي بتوليد السكربت لك
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Input Section */}
          <Card className="p-8">
            <form onSubmit={handleGenerate} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  وصف السكربت المطلوب
                </label>
                <textarea
                  placeholder="مثال: أنشئ سكربت يعرض قائمة بجميع اللاعبين في الخادم..."
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  className="w-full p-3 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-accent"
                  rows={8}
                />
              </div>

              <Button
                type="submit"
                disabled={isLoading}
                className="w-full bg-accent hover:bg-accent/90 flex items-center justify-center gap-2"
              >
                <Sparkles className="w-4 h-4" />
                {isLoading ? "جاري التوليد..." : "توليد السكربت"}
              </Button>
            </form>
          </Card>

          {/* Output Section */}
          <Card className="p-8">
            <div className="space-y-4">
              <h2 className="text-lg font-bold text-foreground">السكربت المولد</h2>

              {generatedScript ? (
                <>
                  <div className="bg-slate-900 text-slate-100 p-4 rounded-lg font-mono text-sm overflow-auto max-h-64">
                    <pre>{generatedScript}</pre>
                  </div>

                  <div className="flex gap-2">
                    <Button
                      onClick={handleCopy}
                      variant="outline"
                      className="flex-1 flex items-center justify-center gap-2"
                    >
                      <Copy className="w-4 h-4" />
                      نسخ
                    </Button>
                    <Button
                      onClick={handleDownload}
                      className="flex-1 bg-accent hover:bg-accent/90 flex items-center justify-center gap-2"
                    >
                      <Download className="w-4 h-4" />
                      تحميل
                    </Button>
                  </div>
                </>
              ) : (
                <div className="bg-muted p-8 rounded-lg text-center text-muted-foreground">
                  <p>السكربت المولد سيظهر هنا</p>
                </div>
              )}
            </div>
          </Card>
        </div>

        {/* Tips */}
        <Card className="mt-8 p-6 bg-blue-50 border-blue-200">
          <h3 className="font-bold text-blue-900 mb-3">نصائح لأفضل النتائج:</h3>
          <ul className="space-y-2 text-sm text-blue-800">
            <li>✓ كن محدداً في وصفك للسكربت</li>
            <li>✓ اذكر الميزات التي تريدها</li>
            <li>✓ حدد لغة البرمجة المطلوبة (Lua, Python, إلخ)</li>
            <li>✓ يمكنك تحسين السكربت المولد يدوياً</li>
          </ul>
        </Card>
      </div>
    </div>
  );
}
