import { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { getScripts, getScriptById, getUserCart, getUserOrders, getScriptReviews, getUserTickets, addScript, deleteScriptById } from "./db";
import { z } from "zod";
import * as db from "./db";
import { sdk } from "./_core/sdk";
import { invokeLLM } from "./_core/llm";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, cookieOptions);
      return {
        success: true,
      } as const;
    }),
    loginWithEmail: publicProcedure
      .input(z.object({ email: z.string().email(), password: z.string().min(6), isSignUp: z.boolean() }))
      .mutation(async ({ input, ctx }) => {
        const { email, password, isSignUp } = input;
        
        // For simplicity, we'll create/update user with email as openId
        const openId = `email_${email}`;
        
        try {
          // Upsert user
          await db.upsertUser({
            openId,
            name: email.split('@')[0],
            email,
            loginMethod: "email",
            lastSignedIn: new Date(),
          });
          
          // Create session token
          const sessionToken = await sdk.createSessionToken(openId, {
            name: email.split('@')[0],
            expiresInMs: ONE_YEAR_MS,
          });
          
          // Set session cookie
          const cookieOptions = getSessionCookieOptions(ctx.req);
          ctx.res.cookie(COOKIE_NAME, sessionToken, { ...cookieOptions, maxAge: ONE_YEAR_MS });
          
          return { success: true };
        } catch (error: any) {
          throw new Error(error.message || "Failed to login with email");
        }
      }),
  }),

  scripts: router({
    list: publicProcedure.query(async () => {
      return await getScripts();
    }),
    
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return await getScriptById(input.id);
      }),

    getReviews: publicProcedure
      .input(z.object({ scriptId: z.number() }))
      .query(async ({ input }) => {
        return await getScriptReviews(input.scriptId);
      }),

    upload: protectedProcedure
      .input(z.object({
        name: z.string(),
        description: z.string(),
        price: z.number(),
        category: z.string(),
        content: z.string(),
      }))
      .mutation(async ({ input, ctx }) => {
        try {
          await addScript({
            title: input.name,
            description: input.description,
            category: input.category,
            price: input.price.toString(),
            fileKey: `script_${ctx.user.id}_${Date.now()}`,
            fileSize: input.content.length,
          });
          return { success: true };
        } catch (error: any) {
          throw new Error(error.message || "Failed to upload script");
        }
      }),
  }),

  cart: router({
    getCart: protectedProcedure.query(async ({ ctx }) => {
      return await getUserCart(ctx.user.id);
    }),

    addToCart: protectedProcedure
      .input(z.object({ scriptId: z.number(), quantity: z.number().default(1) }))
      .mutation(async ({ input, ctx }) => {
        return { success: true };
      }),

    removeFromCart: protectedProcedure
      .input(z.object({ cartItemId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        return { success: true };
      }),
  }),

  orders: router({
    getMyOrders: protectedProcedure.query(async ({ ctx }) => {
      return await getUserOrders(ctx.user.id);
    }),

    createOrder: protectedProcedure
      .input(z.object({ items: z.array(z.object({ scriptId: z.number(), price: z.number() })) }))
      .mutation(async ({ input, ctx }) => {
        return { success: true, orderId: 1 };
      }),
  }),

  tickets: router({
    getMyTickets: protectedProcedure.query(async ({ ctx }) => {
      return await getUserTickets(ctx.user.id);
    }),

    createTicket: protectedProcedure
      .input(z.object({ subject: z.string(), description: z.string(), orderId: z.number().optional() }))
      .mutation(async ({ input, ctx }) => {
        return { success: true, ticketId: 1 };
      }),
  }),

  ai: router({
    generateScript: protectedProcedure
      .input(z.object({ prompt: z.string() }))
      .mutation(async ({ input }) => {
        try {
          const response = await invokeLLM({
            messages: [
              { role: "system", content: "You are a Lua script expert. Generate clean, well-commented Lua code based on user requests." },
              { role: "user", content: input.prompt },
            ],
          });
          const script = response.choices[0].message.content;
          return { script };
        } catch (error: any) {
          throw new Error(error.message || "Failed to generate script");
        }
      }),
  }),

  discord: router({
    sendMessage: protectedProcedure
      .input(z.object({ message: z.string() }))
      .mutation(async ({ input }) => {
        // Discord webhook will be implemented here
        return { success: true };
      }),
  }),

  admin: router({
    addScript: protectedProcedure
      .input(z.object({
        title: z.string(),
        description: z.string().optional(),
        category: z.string(),
        price: z.number(),
        version: z.string().optional(),
        fileKey: z.string(),
        fileSize: z.number(),
        imageUrl: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== 'admin') {
          throw new Error('Unauthorized');
        }
        await addScript({
          title: input.title,
          description: input.description,
          category: input.category,
          price: input.price.toString(),
          imageUrl: input.imageUrl,
          fileKey: input.fileKey,
          fileSize: input.fileSize,
          version: input.version,
        });
        return { success: true, scriptId: 1 };
      }),

    deleteScript: protectedProcedure
      .input(z.object({ scriptId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== 'admin') {
          throw new Error('Unauthorized');
        }
        await deleteScriptById(input.scriptId);
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
