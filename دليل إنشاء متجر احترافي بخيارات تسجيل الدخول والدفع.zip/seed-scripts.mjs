import { drizzle } from "drizzle-orm/mysql2";
import { scripts } from "./drizzle/schema.ts";

const db = drizzle(process.env.DATABASE_URL);

const scriptsData = [
  {
    title: "إعادة تشغيل الخادم",
    category: "أتمتة",
    price: "29.99",
    version: "1.0.0",
    description: "سكربت إعادة تشغيل الخادم مع مؤقت العد التنازلي المباشر - يدعم txAdmin",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663379901621/6RCbR3DpAk72wXbykQAfiA/script-1-server-restart-6PKMR6dtFpcGZFFHs945FU.webp",
    fileKey: "script-1.zip",
    isActive: true,
  },
  {
    title: "المشنقة - قاعدة التنفيذ",
    category: "أدوات",
    price: "39.99",
    version: "1.0.0",
    description: "سكربت Fivem ESX/QBCore - قاعدة التنفيذ",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663379901621/6RCbR3DpAk72wXbykQAfiA/script-2-hangman-PDGeNLoCStceLwu5MyMmHY.webp",
    fileKey: "script-2.zip",
    isActive: true,
  },
  {
    title: "راديو 0R",
    category: "أدوات",
    price: "49.99",
    version: "1.0.0",
    description: "راديو المركبات والطائرات المروحية، جهاز تشويش، 5 أنواع مختلفة من أجهزة الراديو",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663379901621/6RCbR3DpAk72wXbykQAfiA/script-3-radio-GWV7CmuhifFi6hQVwiACcW.webp",
    fileKey: "script-3.zip",
    isActive: true,
  },
  {
    title: "حزمة حركات العصابات المخصصة V2",
    category: "حركات",
    price: "59.99",
    version: "2.0.0",
    description: "حزمة حركات العصابات المخصصة الجديدة لـ FiveM الإصدار الثاني + 11 تعبيرًا - أعمال جوش",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663379901621/6RCbR3DpAk72wXbykQAfiA/script-4-gang-animations-HhiHS9muGJyZSmMU6RvibQ.webp",
    fileKey: "script-4.zip",
    isActive: true,
  },
  {
    title: "سكربت الهلي كام",
    category: "كاميرا",
    price: "34.99",
    version: "1.0.0",
    description: "سكربت كاميرا الهليكوبتر مع تأثيرات احترافية",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663379901621/6RCbR3DpAk72wXbykQAfiA/script-5-heli-cam-BCPA7ycsTFD77DUQdSfSqZ.webp",
    fileKey: "script-5.zip",
    isActive: true,
  },
  {
    title: "برنامج GFX المتقدم للطيار الآلي",
    category: "أتمتة",
    price: "44.99",
    version: "1.0.0",
    description: "برنامج GFX متقدم للطيار الآلي مع واجهة احترافية",
    image: "https://example.com/script-6.jpg",
    fileKey: "script-6.zip",
    isActive: true,
  },
  {
    title: "Lockpick",
    category: "أدوات",
    price: "24.99",
    version: "1.0.0",
    description: "سكربت فتح الأقفال مع واجهة حديثة",
    image: "https://example.com/script-7.jpg",
    fileKey: "script-7.zip",
    isActive: true,
  },
  {
    title: "PREVIEW",
    category: "أدوات",
    price: "19.99",
    version: "1.0.0",
    description: "سكربت معاينة المنتجات",
    image: "https://example.com/script-8.jpg",
    fileKey: "script-8.zip",
    isActive: true,
  },
  {
    title: "لوحات ترخيص وهمية الإصدار 2.0",
    category: "تخصيص",
    price: "29.99",
    version: "2.0.0",
    description: "سكربت لوحات ترخيص وهمية مع تأثيرات هولوجرافية",
    image: "https://example.com/script-9.jpg",
    fileKey: "script-9.zip",
    isActive: true,
  },
  {
    title: "جهاز لوحي متطور لمكافحة الجرائم الإلكترونية",
    category: "أدوات",
    price: "54.99",
    version: "1.0.0",
    description: "جهاز لوحي متطور مع خاصية القيادة تحت تأثير الكحول | ESX/QBOX | كود بازار",
    image: "https://example.com/script-10.jpg",
    fileKey: "script-10.zip",
    isActive: true,
  },
  {
    title: "قائمة الإيقاف المؤقت",
    category: "واجهات",
    price: "39.99",
    version: "1.0.0",
    description: "سكربت FiveM قائمة الإيقاف المؤقت | ESX، QBox، QBCore | سكربتات 2s",
    image: "https://example.com/script-11.jpg",
    fileKey: "script-11.zip",
    isActive: true,
  },
  {
    title: "قدرة قفز الدراجة",
    category: "حركات",
    price: "34.99",
    version: "1.0.0",
    description: "سكربت FiveM قدرة قفز الدراجة | مستقل، ESX، QBCore | 2s",
    image: "https://example.com/script-12.jpg",
    fileKey: "script-12.zip",
    isActive: true,
  },
];

async function seedScripts() {
  try {
    console.log("Starting to seed scripts...");
    
    for (const script of scriptsData) {
      await db.insert(scripts).values({
        title: script.title,
        category: script.category,
        price: script.price,
        version: script.version,
        description: script.description,
        image: script.image,
        fileKey: script.fileKey,
        isActive: script.isActive,
        createdAt: new Date(),
        updatedAt: new Date(),
      });
    }
    
    console.log("✓ Scripts seeded successfully!");
  } catch (error) {
    console.error("Error seeding scripts:", error);
    process.exit(1);
  }
}

seedScripts();
